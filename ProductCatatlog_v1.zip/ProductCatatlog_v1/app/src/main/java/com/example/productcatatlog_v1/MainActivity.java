package com.example.productcatatlog_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    private ImageButton imageButton;
    private EditText teamName;
    private EditText teamAdress;
    private TextView textView;
    private TextView textView2;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton =(ImageButton)findViewById(R.id.imageButton);
        teamName = (EditText)findViewById(R.id.teamName);
        teamAdress = (EditText)findViewById(R.id.teamAdress);
        textView =(TextView)findViewById(R.id.textView);
        textView2 = (TextView)findViewById(R.id.textView2);
        button = (Button)findViewById(R.id.button3);

        String team_name = teamName.getText().toString();
        String team_adress = teamAdress.getText().toString();

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(getApplicationContext(),ChooseAvatar.class);
            startActivityForResult(intent,1);
            }




        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String adress = teamAdress.getText().toString();

                if(TextUtils.isEmpty(adress)){
                    teamAdress.setError("Provide A ZIP Code");
                    return;
                }

                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps?q=+" + adress));
                startActivity(myIntent);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_CANCELED) {
            return;
        } else if (resultCode==1) {

            ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);

            String drawableName = "ic_logo_01";


            switch (data.getIntExtra("Image ID",0)) {

                case R.id.imageButton2:
                    drawableName = "ic_logo_01";
                    break;
                case R.id.imageButton3:
                    drawableName = "ic_logo_02";
                    break;
                case R.id.imageButton4:
                    drawableName = "ic_logo_03";
                    break;
                case R.id.imageButton5:
                    drawableName = "ic_logo_04";
                    break;
                case R.id.imageButton6:
                    drawableName = "ic_logo_05";
                    break;
                default:
                    drawableName = "ic_logo_00";
                    break;
            }
            int resID = getResources().getIdentifier(drawableName, "drawable", getPackageName());
            imageButton.setImageResource(resID);
        }
    }

    }
