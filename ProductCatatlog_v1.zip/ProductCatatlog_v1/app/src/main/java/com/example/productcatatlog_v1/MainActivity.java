package com.example.productcatatlog_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    private ImageButton imageButton;
    private EditText teamName;
    private EditText teamAdress;
    private TextView textView;
    private TextView textView2;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton =(ImageButton)findViewById(R.id.imageButton);
        teamName = (EditText)findViewById(R.id.teamName);
        teamAdress = (EditText)findViewById(R.id.teamAdress);
        textView =(TextView)findViewById(R.id.textView);
        textView2 = (TextView)findViewById(R.id.textView2);
        button = (Button)findViewById(R.id.button3);



        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            startActivity(new Intent (getApplicationContext(),ChooseAvatar.class));
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String adress = teamAdress.getText().toString();

                if(TextUtils.isEmpty(adress)){
                    teamAdress.setError("Provide A ZIP Code");
                    return;
                }

                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps?q=+" + adress));
                startActivity(myIntent);
            }
        });


    }

    }
